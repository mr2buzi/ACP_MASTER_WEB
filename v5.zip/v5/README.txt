CHANGES MADE

- Removed scrollbar for screen using overflow-y bootstrap command
- Sorted out index collapse bar (fixed overlap issue)
- aligned index.html