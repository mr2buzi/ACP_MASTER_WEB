<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
</head>
<body>
    <h1>Registration Error</h1>
    <p>There was an error while trying to create your account. Please try again later.</p>
    <a href="sign_up.php">Back to Sign Up</a>
</body>
</html>
